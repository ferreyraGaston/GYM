    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="../img/pesas.ico" type="image/ico">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script> 
    <script type="text/javascript" src="js/jquery-3.6.0.min.js"></script>
    <?php include "functions.php"; ?>